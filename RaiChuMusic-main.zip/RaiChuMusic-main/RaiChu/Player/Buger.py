"""Making bug """

from os import remove
from random import choice
from carbon.events import register
